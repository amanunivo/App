<template> 
  <div class="position-absolute hero-bg-svg w-100"> 
    <div
      class="bg-cover"
      style="background-image: url('../src/assets/images/bg-1.png')"
    ></div>
  </div>

  <section class="position-relative py-3 py-md-5 hero-banner">
    <div class="container position-relative h-100">
      <div class="row h-100">
        <div class="col-lg-6 hero-caption">
          <h1 class="display-4 font-weight-bold text-white pt-lg-5">
            Live Online Classes for Kids of Age Group 6-18 Yrs
          </h1>
          <p class="lead font-weight-bold text-white-80">
            Interactive Hands-on Learning on Mobile App Development, Game
            Development, Web Development, Data Science, ML Chatbots
          </p>
          <a
            class="btn btn-yellow rounded-full btn-lg px-lg-4 font-weight-bold"
            href="#"
            >Book a Free Demo</a
          >
        </div>
        <div class="col-lg-6 hero-caption px-0">
          <img
            src="../assets/images/banner-img.png"
            class="img-fluid"
            alt="banner"
          />
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3
            class="display-2 font-weight-bold bg-purple d-inline-block p-3 text-white"
          >
            Access LIVE SESSIONS from world-class industry experts
          </h3>
        </div>
        <div class="col-12 px-lg-0">
          <div
            class="grid grid-col-xs-2 grid-col-lg-4 text-center my-lg-5 my-3 text-muted figure-rounded-icon"
          >
            <div class="card p-3 shadow rounded-0">
              <figure class="bg-pink">
                <img src="../assets/images/icons/icon1.png" alt="icon1" />
              </figure>
              <div class="caption lead font-weight-normal rwd-font">
                A dynamic two-way communication channel to simulate a
                classroom-like environment
              </div>
            </div>

            <div class="card p-3 shadow rounded-0">
              <figure class="bg-yellow-2">
                <img src="../assets/images/icons/icon2.png" alt="icon2" />
              </figure>
              <div class="caption lead font-weight-normal rwd-font">
                Innovation whiteboard allows automatic display of notes to all
                participating students
              </div>
            </div>

            <div class="card p-3 shadow rounded-0">
              <figure class="bg-light-orange">
                <img src="../assets/images/icons/icon3.png" alt="icon3" />
              </figure>
              <div class="caption lead font-weight-normal rwd-font">
                Interactive classes where teachers have the ability to zoom,
                highlight, draw and write
              </div>
            </div>

            <div class="card p-3 shadow rounded-0">
              <figure class="bg-sky-blue">
                <img src="../assets/images/icons/icon4.png" alt="icon4" />
              </figure>
              <div class="caption lead font-weight-normal rwd-font">
                Students are grouped into breakout rooms for team collaboration
                to facilitate interactive Learning
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="position-relative video-section py-lg-5 py-3">
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3 class="display-3 font-weight-bold d-block p-3">
            <!--  Book a <span>Demo Class for Free</span>-->
            <img
              src="../assets/images/heading-text-with-bg.png"
              class="img-fluid user-select-none"
              alt="heading"
            />
          </h3>
          <a
            class="btn btn-pink text-white rounded-full btn-lg px-lg-4 font-weight-bold"
            href="#"
            >Book a Free Demo</a
          >
        </div>
        <div class="col-12 col-lg-8 text-center mx-auto px-lg-0 my-5">
          <img
            src="../assets/images/blackboard.png"
            width="100%"
            alt="blackboard"
          />
        </div>
      </div>
    </div>

    <figure
      class="position-absolute bg-cover"
      style="background-image: url('../src/assets/images/bg-2.png')"
    ></figure>
  </section>

  <section class="position-relative py-lg-5 py-3 index-1">
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3 class="display-3 font-weight-bold d-block p-3">
            <!--  Book a <span>Demo Class for Free</span>-->
            <img
              src="../assets/images/heading-text-with-bg2.png"
              class="img-fluid user-select-none"
              alt="heading"
            />
          </h3>
        </div>
        <div
          class="grid grid-col-xs-2 grid-col-md-3 grid-col-lg-5 text-center my-lg-5 my-3 text-muted figure-rounded-icon"
        >
          <div class="p-3 rounded-0">
            <figure>
              <img src="../assets/images/icons/yr-kid-1.png" alt="kid1" />
            </figure>
            <div class="caption lead font-weight-normal rwd-font">
              <h4 class="font-weight-bold">Become detail oriented</h4>
            </div>
          </div>

          <div class="p-3 rounded-0">
            <figure>
              <img src="../assets/images/icons/yr-kid-2.png" alt="kid2" />
            </figure>
            <div class="caption lead font-weight-normal rwd-font">
              <h4 class="font-weight-bold">Problem Solving</h4>
            </div>
          </div>

          <div class="p-3 rounded-0">
            <figure>
              <img src="../assets/images/icons/yr-kid-3.png" alt="kid3" />
            </figure>
            <div class="caption lead font-weight-normal rwd-font">
              <h4 class="font-weight-bold">Structure</h4>
            </div>
          </div>

          <div class="p-3 rounded-0">
            <figure>
              <img src="../assets/images/icons/yr-kid-4.png" alt="kid4" />
            </figure>
            <div class="caption lead font-weight-normal rwd-font">
              <h4 class="font-weight-bold">Algorithmic Thinking</h4>
            </div>
          </div>

          <div class="p-3 rounded-0">
            <figure>
              <img src="../assets/images/icons/yr-kid-5.png" alt="kid5" />
            </figure>
            <div class="caption lead font-weight-normal rwd-font">
              <h4 class="font-weight-bold">Creative Expression</h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="position-relative py-3 py-md-5 we-offer-section">
    <div class="container position-relative h-100">
      <div class="row h-100">
        <div class="col-12 text-center">
          <h3 class="display-3 font-weight-bold d-block p-3">
            <img
              src="../assets/images/heading-text-with-bg3.png"
              class="img-fluid user-select-none"
              alt="heading"
            />
          </h3>
        </div>

        <div class="w-100 d-inline-block">
          <div class="grid grid-col-xs-1 grid-col-md-2 grid-col-lg-3 w-100">
              <!-- Vue Loop -->
            <div class="card-box" v-for="CourseCate in CourseCategory"  :key="CourseCate.id">
                <figure>
                    <img src="/src/assets/images/we-offer-3.png" alt="" class="img-fluid" />
                   <!--  <img  :src="'/src/assets/images/'+CourseCate.image" alt="offer" class="img-fluid" /> -->
                </figure> 
                <div class="caption bg-white shadow"> 
                <h3 class="h1 font-weight-bold text-pink"> {{ CourseCate.name }}</h3>
                <h5 class="font-weight-bold text-muted">6 Years to 18 Years</h5>
                <hr />
                <h5 class="text-purpule font-weight-bold">
                  Benefits of Coding
                </h5>
                <div v-html="CourseCate.description"></div>
                <a
                  href="#"
                  class="btn bg-purple btn-block text-white font-weight-bold"
                  >Explore Courses</a
                >
                <a href="#" class="btn bg-yellow btn-block font-weight-bold"
                  >Book a Free Demo</a
                >
              </div>
                <!--End Vue Loop -->

            </div> 
          </div>
        </div>
      </div>
    </div>
    <figure class="bg-style2">
      <!--  <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjUwIiBoZWlnaHQ9IjUyOSIgdmlld0JveD0iMCAwIDY1MCA1MjkiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxtYXNrIGlkPSJtYXNrMCIgbWFzay10eXBlPSJhbHBoYSIgbWFza1VuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeD0iMCIgeT0iMCIgd2lkdGg9IjY1MCIgaGVpZ2h0PSI1MjkiPgo8cmVjdCB3aWR0aD0iNjUwIiBoZWlnaHQ9IjUyOSIgZmlsbD0iI0M0QzRDNCIvPgo8L21hc2s+CjxnIG1hc2s9InVybCgjbWFzazApIj4KPHBhdGggZD0iTTIzNS4zMzcgNDE1LjIyMUMxMTEuODkzIDU0MS4zNTYgMjAuNDA4OSA1MjYuNDI3IC05LjkwMjYgNTAzLjE5NkMtMTMuMDA3NiA1MDEuMDI5IC0xMy45ODE3IDQ5Ny40OTUgLTE0LjA4MDcgNDk1Ljk5OUw3Ljc2NzE2IDE0LjQ5NDNMNjYzLjM0MiAzOC43MzQ4TDY0OS42NzYgMzM5LjkyNUM2MzAuNTc0IDMzMC43MTYgNTc1LjE5MSAzMDQuODEzIDUwNi40NzggMjc0Ljg2N0M0MzcuNzY0IDI0NC45MjIgMzc3LjcwOSAyNzcuODY3IDM1Ni4yNzEgMjk4LjA4M0MzMzMuOTMyIDMxMy44ODYgMjY2LjM0IDM4Mi43NiAyMzUuMzM3IDQxNS4yMjFaIiBmaWxsPSIjREREREREIi8+CjxwYXRoIGQ9Ik0yNDEgMzkxQzEyMy40IDUyMi42IDMxLjMzMzMgNTExLjgzMyAwIDQ5MEMtMy4yIDQ4Ny45NzYgLTQuMzMzMzMgNDg0LjQ5IC00LjUgNDgzVjFMNjUxLjUgLTQuNVYyOTdDNjMyIDI4OC42NjcgNTc1LjUgMjY1LjMgNTA1LjUgMjM4LjVDNDM1LjUgMjExLjcgMzc3IDI0Ny4zMzMgMzU2LjUgMjY4LjVDMzM0LjkgMjg1LjMgMjcwLjUgMzU3LjE2NyAyNDEgMzkxWiIgZmlsbD0iI0ZDNkI4QyIvPgo8cGF0aCBkPSJNLTguNSAzMThDMTUuODMzMyAzNTEuNSA5MC4xIDQwMiAxOTIuNSAzMzZDMzIwLjUgMjUzLjUgMzc4LjUgMTc4IDU0OS41IDI0My41QzY4Ni4zIDI5NS45IDcyOS4xNjcgMzEzLjMzMyA3MzMuNSAzMTUuNSIgc3Ryb2tlPSJ1cmwoI3BhaW50MF9saW5lYXIpIiBzdHJva2Utd2lkdGg9IjEwIi8+CjwvZz4KPGRlZnM+CjxsaW5lYXJHcmFkaWVudCBpZD0icGFpbnQwX2xpbmVhciIgeDE9IjQwOS41IiB5MT0iMjE5IiB4Mj0iMTIwLjUiIHkyPSIzODQiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KPHN0b3Agc3RvcC1jb2xvcj0iI0VBNjQ4MSIvPgo8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNCMjRCNjMiLz4KPC9saW5lYXJHcmFkaWVudD4KPC9kZWZzPgo8L3N2Zz4K"
             alt="">-->
      <img src="../assets/images/svg/Vector%20Smart%20Object.svg" alt="" />
    </figure>
  </section>

  <section>
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3 class="display-3 font-weight-bold d-inline-block p-3 text-muted">
            Management and Instructors are from
          </h3>
        </div>
        <div class="col-12 px-lg-0">
          <ul
            class="list-unstyled d-flex flex-wrap flex-lg-nowrap text-center my-lg-5 my-3 align-items-center justify-content-between"
          >
            <li class="w-50">
              <img
                src="../assets/images/others-logo/1.png"
                alt=""
                class="img-fluid"
              />
            </li>
            <li class="w-50">
              <img
                src="../assets/images/others-logo/2.png"
                alt=""
                class="img-fluid"
              />
            </li>
            <li class="w-50">
              <img
                src="../assets/images/others-logo/3.png"
                alt=""
                class="img-fluid"
              />
            </li>
            <li class="w-50">
              <img
                src="../assets/images/others-logo/4.png"
                alt=""
                class="img-fluid"
              />
            </li>
            <li class="w-50">
              <img
                src="../assets/images/others-logo/5.png"
                alt=""
                class="img-fluid"
              />
            </li>
            <li class="w-50">
              <img
                src="../assets/images/others-logo/6.png"
                alt=""
                class="img-fluid"
              />
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section class="position-relative py-lg-5 py-3">
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3 class="display-3 font-weight-bold d-block p-3">
            <img
              src="../assets/images/heading-text-with-bg4.png"
              class="img-fluid user-select-none"
              alt="heading"
            />
          </h3>
        </div>
        <div class="col-12 col-lg-8 text-center mx-auto px-lg-0 my-5">
          <img
            src="../assets/images/how-it-work-img.png"
            width="100%"
            alt="how-it-work"
          />
        </div>
      </div>
    </div>
  </section>

  <section class="position-relative py-lg-5 py-3">
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3 class="display-3 font-weight-bold d-block p-3">
            <img
              src="../assets/images/heading-text-with-bg5.png"
              class="img-fluid user-select-none"
              alt="heading"
            />
          </h3>
        </div>
        <div
          class="grid grid-col-md-2 grid-col-lg-2 my-5 w-100 testimonial--section"
        >
          <div class="mr-lg-3 position-relative">
            <div class="test-caption d-flex">
              <div>
                <h4>Shubham Kothawade</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
                  diam nonummy nibh euismod tincidunt ut laoreet dolore magna
                  aliquam erat volutpat. U
                </p>
                <b class="float-right">-(Calicut)</b>
              </div>
              <figure>
                <img src="../assets/images/testi-1.png" alt="testi" />
              </figure>
            </div>
            <svg
              width="100%"
              height="495"
              viewBox="0 0 621 495"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M0.5 169.5V495C52.1 387 174 368 228.5 372H455C579.4 355.2 617.167 248.667 620.5 197.5C623.3 61.5 506.5 4.49999 455 1.49999C403.5 -1.50001 327.5 1.49999 189.5 1.49999C51.5 1.49999 6 113.5 0.5 169.5Z"
                fill="#00b6be"
              />
            </svg>
          </div>
          <div class="ml-lg-3 position-relative">
            <div class="test-caption d-flex">
              <div>
                <h4>Sapana Sawant</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
                  diam nonummy nibh euismod tincidunt ut laoreet dolore magna
                  aliquam erat volutpat. U
                </p>
                <b class="float-right">-(Mumbai)</b>
              </div>
              <figure>
                <img src="../assets/images/testi-2.png" alt="testi" />
              </figure>
            </div>
            <svg
              width="100%"
              height="495"
              viewBox="0 0 621 495"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M0.5 169.5V495C52.1 387 174 368 228.5 372H455C579.4 355.2 617.167 248.667 620.5 197.5C623.3 61.5 506.5 4.49999 455 1.49999C403.5 -1.50001 327.5 1.49999 189.5 1.49999C51.5 1.49999 6 113.5 0.5 169.5Z"
                fill="#fe912a"
              />
            </svg>
          </div>
          <div class="mr-lg-3 position-relative">
            <div class="test-caption d-flex">
              <div>
                <h4>Aakansha Parulekar</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
                  diam nonummy nibh euismod tincidunt ut laoreet dolore magna
                  aliquam erat volutpat. U
                </p>
                <b class="float-right">-(Ahmedabad)</b>
              </div>
              <figure>
                <img src="../assets/images/testi-3.png" alt="testi" />
              </figure>
            </div>
            <svg
              width="100%"
              height="495"
              viewBox="0 0 621 495"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M0.5 169.5V495C52.1 387 174 368 228.5 372H455C579.4 355.2 617.167 248.667 620.5 197.5C623.3 61.5 506.5 4.49999 455 1.49999C403.5 -1.50001 327.5 1.49999 189.5 1.49999C51.5 1.49999 6 113.5 0.5 169.5Z"
                fill="#FF516A"
              />
            </svg>
          </div>
          <div class="ml-lg-3 position-relative">
            <div class="test-caption d-flex">
              <div>
                <h4>Mayuri Joshi</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
                  diam nonummy nibh euismod tincidunt ut laoreet dolore magna
                  aliquam erat volutpat. U
                </p>
                <b class="float-right">-(Goa)</b>
              </div>
              <figure>
                <img src="../assets/images/testi-4.png" alt="testi" />
              </figure>
            </div>
            <svg
              width="100%"
              height="495"
              viewBox="0 0 621 495"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M0.5 169.5V495C52.1 387 174 368 228.5 372H455C579.4 355.2 617.167 248.667 620.5 197.5C623.3 61.5 506.5 4.49999 455 1.49999C403.5 -1.50001 327.5 1.49999 189.5 1.49999C51.5 1.49999 6 113.5 0.5 169.5Z"
                fill="#3c3d88"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  </section>


</template>

<script> 
import axios from 'axios'

export default {
  data() {
    return {
      Course: null,
      CourseCategory: null,
    };
  },
  mounted() {
    axios.get('http://13.232.127.167/afaapi/api.php?fn=Course').then((response) => {
      console.log(this.Course = response.data);
    });
    
   axios.get('http://13.232.127.167/afaapi/api.php?fn=CourseCategory').then((response) => {
      console.log(this.CourseCategory = response.data);
    });
  }
};
</script>

<style>
</style>